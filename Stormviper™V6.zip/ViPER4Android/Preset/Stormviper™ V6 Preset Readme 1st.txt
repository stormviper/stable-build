﻿
Please Read..

Stormviper™ V6 Preset are collection of custom Viper4android™presets and are design to be used with any type of media files you consumed.

V6 has been divided to four categories so it is much easier to select. 

We only support Stormviper ™as a whole or as a complete preset. Convolver and DDC used in stormviper Unity were customised for this version.

Installation? 
1. You must have Viper4android installed.either
V2.7, vr2.5, 3.4.2,0, v4.4, or legacy versions
2. Extract stormviper.zip to the root directory where
Your viper4android folder resides.
3. We recomend your delete everything in the viper4android
Folder and only then copy all files in the zip.
4.You can load the presets via your viper4androidt app
Enjoy!

Stormviper may be used freely and not be sold.

Contact me via Telegram Channel @stormaudio
®2019 Stormviper™ . ALL RIGHTS. NUMBSKULL



